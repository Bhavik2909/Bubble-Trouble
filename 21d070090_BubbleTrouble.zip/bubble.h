#include <simplecpp>
#include "shooter.h"

/* Bubble Vars */
const int BUBBLE_START_X = 250;
const int BUBBLE_START_Y = 50;
const int BUBBLE_DEFAULT_RADIUS = 8;
const int BUBBLE_RADIUS_THRESHOLD = 10;
const int BUBBLE_DEFAULT_VX = 80;
const int BUBBLE_DEFAULT_VY = 100;
const int BUBBLE_GRAVITY = 150;
const int BUBBLE_MAX_HEIGHT = 460;
const int BUBBLE_MIN_HEIGHT = 40;



class Bubble
{
private:
    Circle circle;  // the circle representing the bubble
    double vx, vy, a;  // velocity in x and y direction
                              // a is acceleration
    Color color;    // color of the bubble

public:
    Bubble(double cx, double cy, double r, double vx_=BUBBLE_DEFAULT_VX, double vy_=BUBBLE_DEFAULT_VY, Color color_=COLOR(0, 0, 255))
    {
        // Bubble constructor
        color = color_;
        circle = Circle(cx, cy, r);
        circle.setColor(color);
        circle.setFill(true);

        vx = vx_;
        a = BUBBLE_GRAVITY;
        vy = vy_;          //initial velocity
    }

    int new_vx ;      //velocity after each nextStep
    int new_vy ;


    void nextStep(double t)
    {
        // move the bubble
        vy = vy+a*t;   //velocity along y
        double new_x = circle.getX() + vx*t;
        double new_y = circle.getY() + vy*t+0.5*a*t*t;   //kinematics

        if ((vx < 0 && new_x < (0 + circle.getRadius())) // bounce along X direction at left border
            ||
            (vx > 0 && new_x > (WINDOW_X - circle.getRadius()))) // bounce along X direction at right border
        {

            vx = -vx;
            new_x = circle.getX() + vx*t;

        }


        else if ((vy < 0 && new_y < ( BUBBLE_MIN_HEIGHT + circle.getRadius())) // bounce along Y at top
            ||
            (vy > 0 && new_y > (BUBBLE_MAX_HEIGHT - circle.getRadius()))) // bounce along Y at play line
        {
            vy = -vy+a*t;
            new_y = circle.getY() + vy*t;      //kinematics

        }
        new_vx = vx;
        new_vy = vy;

        circle.moveTo(new_x, new_y);
    }

    double get_radius()
    {
        // return the radius of the bubble
        return circle.getRadius();
    }

    double get_center_x()
    {
        // return the x coordinate of the center of the bubble
        return circle.getX();
    }

    double get_center_y()
    {
        // return the y coordinate of the center of the bubble
        return circle.getY();
    }

    double get_vx()
    {
        // return the x velocity of the bubble
        return vx;
    }
    double get_vy()
    {
        // return the y velocity of the bubble
        return vy;
    }

    Color get_color()
    {
        // return the color of the bubble
        return color;
    }
};
