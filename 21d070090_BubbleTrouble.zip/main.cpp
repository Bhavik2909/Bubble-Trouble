#include <simplecpp>
#include "bubble.h"

/* Simulation Vars */
const double STEP_TIME = 0.02;

/* Game Vars */
const int PLAY_Y_HEIGHT = 460;
const int LEFT_MARGIN = 70;
const int TOP_MARGIN = 40;
const int BOTTOM_MARGIN = 475;
const int TIME_FOR_LEVEL1 = 20;
const int LIFE = 3;



string reversestr (string s){

//reverse string
    string x;
    for (int i = s.size(); i>0; i--){
        x.push_back (s[i-1]);
    }
    return x;
}


string convertint(int n){

// convert number to string
    string s;
    int n1 = n%10;
    s.push_back(n1+'0');
    n = n/10;
    if (n<=9) {s.push_back(n+'0'); return s;}
    else {s.append(convertint(n)); return s;}
}


void move_bullets(vector<Bullet> &bullets){
    // move all bullets
    for(unsigned int i=0; i<bullets.size(); i++){
        if(!bullets[i].nextStep(STEP_TIME)){
            bullets.erase(bullets.begin()+i);
        }
    }
}

void move_bubbles(vector<Bubble> &bubbles){
    // move all bubbles
    for (unsigned int i=0; i < bubbles.size() ; i++)
    {
        bubbles[i].nextStep(STEP_TIME);
    }
}

vector<Bubble> create_bubbles(int n)
{
    // adjust colors of bubbles according to levels
    int x=0, y=0, z=0;
    if (n==1) y =255;
    else if (n==2) z =255;
    else {x = 200; y=200;}

    vector<Bubble> bubbles;
    bubbles.push_back(Bubble(WINDOW_X/2.0, PLAY_Y_HEIGHT/9, BUBBLE_DEFAULT_RADIUS, -BUBBLE_DEFAULT_VX*n, BUBBLE_DEFAULT_VY, COLOR(x,y,z)));
    bubbles.push_back(Bubble(WINDOW_X/4.0, PLAY_Y_HEIGHT/9, BUBBLE_DEFAULT_RADIUS, BUBBLE_DEFAULT_VX*n, BUBBLE_DEFAULT_VY, COLOR(x,y,z)));

    if (n>=2){
    // create level 2 bubbles
    bubbles.push_back(Bubble(WINDOW_X/2.0, PLAY_Y_HEIGHT/9, 2*BUBBLE_DEFAULT_RADIUS, -BUBBLE_DEFAULT_VX*n/2, BUBBLE_DEFAULT_VY, COLOR(x,y,z)));
    bubbles.push_back(Bubble(WINDOW_X/4.0, PLAY_Y_HEIGHT/9, 2*BUBBLE_DEFAULT_RADIUS, BUBBLE_DEFAULT_VX*n/2, BUBBLE_DEFAULT_VY, COLOR(x,y,z)));
    }

    if (n==3){
    //creates level 3 bubbles
    bubbles.push_back(Bubble(WINDOW_X/2.0, PLAY_Y_HEIGHT/9, 4*BUBBLE_DEFAULT_RADIUS, -BUBBLE_DEFAULT_VX*n/3, BUBBLE_DEFAULT_VY, COLOR(x,y,z)));
    bubbles.push_back(Bubble(WINDOW_X/4.0, PLAY_Y_HEIGHT/9, 4*BUBBLE_DEFAULT_RADIUS, BUBBLE_DEFAULT_VX*n/3, BUBBLE_DEFAULT_VY, COLOR(x,y,z)));
    }

    return bubbles;

}



int main()
{
    //continue the game with next level
    bool nextlevel = true;

    //Score initialization
    int score = 0;

    //Health and time left to resume variables (timeout variables' values have no importance here)
    int life = LIFE, timeout3 = -99;
    double timeout = 100;

    //Level number
    int leveln = 1;
    initCanvas("Bubble Trouble", WINDOW_X, WINDOW_Y);


    while (nextlevel){

    //Level representation
    Text levelnumber1(WINDOW_X/2, PLAY_Y_HEIGHT/2, "LEVEL   ");
    Text levelnumber2(WINDOW_X/2 + textWidth("LEVEL   ")/2, PLAY_Y_HEIGHT/2, leveln);
    wait(5);

    levelnumber1.moveTo(WINDOW_X - LEFT_MARGIN, BOTTOM_MARGIN);
    levelnumber2.moveTo(WINDOW_X - LEFT_MARGIN + textWidth("LEVEL   ")/2, BOTTOM_MARGIN);
    levelnumber2.setColor(COLOR("red"));

    //PLAYING CONDITIONS
    bool play = true;
    nextlevel = false;

    //create another bubble and it's variables
    bool another = false;
    double new_x, new_y, new_velx, new_vely, new_radius;

    //number of bubbles hit in a level
    int hits = 0;

    //BOTTOM LINE
    Line b1(0, PLAY_Y_HEIGHT, WINDOW_X, PLAY_Y_HEIGHT);
    b1.setColor(COLOR(255, 0, 255));

    //TOP LINE
    Line b2(0, TOP_MARGIN, WINDOW_X, TOP_MARGIN);
    b2.setColor(COLOR(255, 0, 255));

    //TIME initialization
    double time = 0;
    Text time1(LEFT_MARGIN, 3*TOP_MARGIN/5, "TIME   ");
    Text time2(LEFT_MARGIN+ textWidth("TIME   ")/2, 3*TOP_MARGIN/5, time);
    time2.setColor(COLOR(128,0,0));

    //Score initialization
    Text score1(WINDOW_X - LEFT_MARGIN, 3*TOP_MARGIN/5, "SCORE  ");
    Text score2(WINDOW_X - LEFT_MARGIN + 3*textWidth("SCORE  ")/4, 3*TOP_MARGIN/5, score);
    score2.setColor(COLOR(0,0,128));

    //HEALTH
    Text life1(WINDOW_X/2, 3*TOP_MARGIN/5, "HEALTH   ");
    Text life2(WINDOW_X/2 + textWidth("HEALTH   ")/2, 3*TOP_MARGIN/5, life);
    life2.setColor(COLOR(255,165,0));

    //Time left to resume message
    Text timeout1(WINDOW_X/2, PLAY_Y_HEIGHT/2, "RESUME IN   ");
    Text timeout2(WINDOW_X/2, PLAY_Y_HEIGHT/2 + textWidth("RESUME IN   ")/2, timeout3);

    //not to displayed unless hit
    timeout1.setColor(COLOR("white"));
    timeout2.setColor(COLOR("white"));

    //BOTTOM LINE TEXT
    string msg_cmd("Cmd: _");
    Text charPressed(LEFT_MARGIN, BOTTOM_MARGIN, msg_cmd);


    // Intialize the shooter
    Shooter shooter(SHOOTER_START_X, SHOOTER_START_Y, SHOOTER_VX);

    // Initialize the bubbles
    vector<Bubble> bubbles = create_bubbles(leveln);

    // Initialize the bullets (empty)
    vector<Bullet> bullets;

    XEvent event;






    // Main game loop
    while (play)
    {



        // Change level if all bubbles hit
        if (hits== 2*pow(4,leveln-1)){
        nextlevel = true;
        leveln++;
        break;}


        //CREATING BUBBLES
        if (another){

        //New bubble needed is smallest
        if (new_radius==BUBBLE_DEFAULT_RADIUS){

        //SMALLER BUBBLES CREATED WHEN HIGHER BUBBLES HIT
        bubbles.push_back(Bubble(new_x, new_y, new_radius, -new_velx, new_vely, COLOR(200*(leveln-2),200*(leveln-2),255*(3-leveln))));
        bubbles.push_back(Bubble(new_x, new_y, new_radius, new_velx, new_vely, COLOR(200*(leveln-2),200*(leveln-2),255*(3-leveln))));
        }

        else {
        bubbles.push_back(Bubble(new_x, new_y, new_radius, -new_velx, new_vely, COLOR(200,200,0)));
        bubbles.push_back(Bubble(new_x, new_y, new_radius, new_velx, new_vely, COLOR(200,200,0)));
        }

        another = false;
        }



        bool pendingEvent = checkEvent(event);
        if (pendingEvent)
        {
            // Get the key pressed
            char c = charFromEvent(event);
            msg_cmd[msg_cmd.length() - 1] = c;
            charPressed.setMessage(msg_cmd);


            // Update the shooter

            if(c == 'a')
                shooter.move(STEP_TIME, true);
            else if(c == 'd')
                shooter.move(STEP_TIME, false);

            // shooting allowed only when time is resumed if shooter is hit
            else if((c == 'w')&&(timeout3<=0))
                bullets.push_back(shooter.shoot());
            else if(c == 'q')
                return 0;
        }



            // GAME LOST
            for (unsigned int i=0; i<bubbles.size(); i++){
                int yb = bubbles[i].get_center_y(), ysh = shooter.get_head_center_y(), xb = bubbles[i].get_center_x(), xsh = shooter.get_head_center_x();
                int xsb = shooter.get_body_center_x(), sr = shooter.get_head_radius(), br = bubbles[i].get_radius();

                //Checking if y of bubble is below shooter top
                if ( yb + sr + br >= ysh){


                //Collision with shooter body
                    if (yb >= ysh + sr){

                        if (abs(xb - xsb)< br + shooter.get_body_width()/2){

                            // if only 1 life left and there is no timeout
                            if ((life==1)&&(timeout3<=0)){
                                string life4 = convertint(0);
                                life2.setMessage(reversestr(life4));
                                shooter.shooter_timeout(true);
                                Text t(WINDOW_X/2, PLAY_Y_HEIGHT/2, "GAME OVER");
                                t.setColor(COLOR("red"));
                                beginFrame();
                                wait(2);
                                play = false;
                                break;
                            }

                            else {

                            //REDUCE LIFE AND START COUNTDOWN TO RESUME AND CHANGE SHOOTER COLOR
                            if (timeout3<=0){
                                shooter.shooter_timeout(true);
                                life--;
                                timeout = 0;
                                timeout3 = 4;
                                }
                            }
                        }
                    }
                //Collision with shooter head
                    else if ((yb-ysh)*(yb-ysh)+ (xb-xsh)*(xb-xsh)<= (br+sr)*(br+sr)) {


                        // IF ONLY 1 LIFE LEFT THEN GAME OVER
                        if ((life==1)&&(timeout3<=0)){
                            Text t(WINDOW_X/2, PLAY_Y_HEIGHT/2, "GAME OVER");
                            t.setColor(COLOR("red"));
                            shooter.shooter_timeout(true);
                            beginFrame();
                            wait(2);
                            play = false;
                            break;
                        }


                        // REDUCE LIFE AND START COUNTDOWN TO RESUME AND CHANGE SHOOTER COLOR
                        else {
                            if (timeout3<=0){
                            shooter.shooter_timeout(true);
                            life--;
                            timeout = 0;
                            timeout3 = 4;

                            }
                        }
                    }
                }
            }


        // Update the bubbles

        move_bubbles(bubbles);

        // Update the bullets
        move_bullets(bullets);

        //Shooting the bubbles
        for (unsigned int i=0; i<bullets.size(); i++){
            for (unsigned int j=0; j<bubbles.size(); j++){

                if (abs(bubbles[j].get_center_x() - bullets[i].get_center_x()) <= bubbles[j].get_radius() + bullets[i].get_width()/2)
                    if (abs(bubbles[j].get_center_y() - bullets[i].get_center_y()) <= bubbles[j].get_radius() + bullets[i].get_height()/2){

                        //updating score
                        score = score + bubbles[j].get_radius();
                        string scor = convertint(score);
                        score2.setMessage(reversestr(scor));

                        //checking level of bubble hit
                        if (bubbles[j].get_radius() != BUBBLE_DEFAULT_RADIUS){

                        // HIGHER LEVEL BUBBLE HIT
                        another = true;

                        //new bubbles variables
                        new_x = bubbles[j].get_center_x();  new_y = bubbles[j].get_center_y();
                        new_velx = 2* bubbles[j].new_vx ;
                        new_vely = bubbles[j].new_vy/2 ;
                        new_radius = bubbles[j].get_radius()/2;
                        }

                        //erase bubble and bullet
                        bullets.erase(bullets.begin()+i);
                        bubbles.erase(bubbles.begin()+j);
                        hits++;

                    }
            }
        }

        //GAME WON
        if (hits==22) {
                        Text congo(WINDOW_X/2, PLAY_Y_HEIGHT/2, "CONGRATULATIONS!!");
                        congo.setColor(COLOR("blue"));
                        beginFrame();
                        wait(2);
                        play = false;
                        break;
                        }

        wait(STEP_TIME);

        // change shooter color to original
        shooter.shooter_timeout(false);

        //UPDATE TIME
        time = time + STEP_TIME;
        int t = TIME_FOR_LEVEL1*leveln - time/1;

        string tim = convertint(t);
        time2.setMessage(reversestr(tim));


        // UPDATE HEALTH
        string life4 = convertint(life);
        life2.setMessage(reversestr(life4));


        // Update time left to resume again
        timeout = timeout + STEP_TIME;


        if (timeout3>0) {
        timeout3 = 4 - timeout/1;
        string timeout4 = convertint(timeout3);
        timeout2.setMessage(reversestr(timeout4));
        timeout2.setColor(COLOR("green"));
        timeout1.setColor(COLOR("green"));
        }

        else {
        timeout2.setColor(COLOR("white"));
        timeout1.setColor(COLOR("white"));

        }




        // OUT OF TIME
        if (t==0) {
            Text t(WINDOW_X/2, PLAY_Y_HEIGHT/2, "GAME OVER");
            t.setColor(COLOR("red"));

            //Removing resume message if there
            timeout1.setColor(COLOR("white"));
            timeout2.setColor(COLOR("white"));

            beginFrame();
            wait(2);
            play = false;
            break;
        }

    }



    //Wait before starting next level or restarting
    wait(0.5);


    // RESTART GAME
    if (!play){
    endFrame();

        Text repl(WINDOW_X/4, WINDOW_Y/4+ BOTTOM_MARGIN/2, "PLAY AGAIN ??");
        Text endgame(3*WINDOW_X/4, WINDOW_Y/4+ BOTTOM_MARGIN/2, "EXIT");
        int widthrepl = textWidth("PLAY AGAIN ??");
        int widthend = textWidth("EXIT");

        Rectangle replay(WINDOW_X/4, WINDOW_Y/4+ BOTTOM_MARGIN/2, widthrepl+4, 20);
        Rectangle exit(3*WINDOW_X/4, WINDOW_Y/4+ BOTTOM_MARGIN/2, widthend+4, 20);

        // USER INPUT
        getClick();
        int w = getClick();
        int xofuser = w/65536, yofuser = w % 65536;


        if ((abs(xofuser-WINDOW_X/4)<= widthrepl/2 + 2)&&(abs(yofuser-(WINDOW_Y/4+ BOTTOM_MARGIN/2))<= 10)) {

            //reinitializing all the variables before while of next level
            nextlevel=true; leveln =1;
            score = 0;
            life = LIFE; timeout3 = -99; timeout = 100;

            continue;
            }

            // EXIT GAME
        else if ((abs(xofuser-3*WINDOW_X/4)<= widthend/2 + 2)&&(abs(yofuser-(WINDOW_Y/4+ BOTTOM_MARGIN/2))<= 10)) {break;}
    }
  }
}
