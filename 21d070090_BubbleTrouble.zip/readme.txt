Link of project video : https://drive.google.com/drive/folders/1Y40NOz6nk8d8Cb5xwVzOtU67gkRJGZZ3?usp=sharing


Features present:

1) Required Features : 
   1. Parabolic movement of bubbles.
   2. Collision between the bubble and the bullet; the bubble and the bullet disappear after hitting each other.
   3. Collision between the bubble and the shooter; the shooter is dead if the bubble hits it. The shooter changes it's colour for a moment
      if hitting the bubble cause it to lose it's health. This change lasts only for a moment and shooter returns back to it's original
      form.

2) Extra Features :
   1. Bubbles of different sizes. When a bullet hits the larger bubbles, they split into smaller bubbles (half the radius of the original 
      bubble) and move in horizantal and vertical directions like an elastic collision.
   2. 3 Levels present. The next levels become difficult in terms of more bubbles, faster bubbles and bigger bubbles. Bubbles in different
      levels have different colours. 
   3. A score, time and a health counter. The score increases whenever we hit a bubble. The game gets over when we run out of time 
      (measured in seconds) or if we run out of health (whenever the bubble hits the shooter, the health reduces by 1). (In the video 
      provided, the score increases by a factor of 8. Hitting larger bubbles increases the score by a factor of 16 or 24).
   4. Ability to restart or exit the game once the game ends. The game can end by either winning or losing. (This feature can be seen at 
      the end of every video provided in the link). Playing again resets all the previous data.
   5. The shooter loses the ability to shoot bullets for a short duration upon getting hit by the bubble and losing it's health. During 
      this time, the shooter is free to move and bubble can do no damage to it whatsoever. The game resumes after this short duration. 
      (This feature can be seen at 
      1] game_win.webm -  Timestamp :-  1:24 mins
      2] game_lose_via_time.webm - Timestamp :-  0:09 mins and 0:35 mins
      3] game_lose_via_hits.webm - Timestamp :-  0:08 mins and 0:16 mins
      4] play_again_and_timeout.webm - Timestamp :- 0:10, 0:28, 1:15 mins)      